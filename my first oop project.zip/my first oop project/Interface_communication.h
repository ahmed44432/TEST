#pragma once

#include <iostream>
#include <string>

using namespace std;

class Interface_communication
{

public :

	virtual void send_EMAIL(string title, string body) = 0;
	virtual void send_FAX(string title, string body) = 0;
	virtual void send_SMS(string title, string body) = 0;


};

