#pragma once

#include <iostream>
#include "cls_user.h"


cls_user current_user = cls_user::Find("", "");


